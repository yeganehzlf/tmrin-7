#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int n, fib1 = 1, fib2 = 1, t;
	cout << "please enter a number:";
	cin >> n;
	for (int i = 3; i < n; i++)
	{
		t = fib2;
		fib2 = fib1+fib2;
		fib1 = t;
	}
	cout <<t;
}